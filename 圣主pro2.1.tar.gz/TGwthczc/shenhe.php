
<!DOCTYPE HTML>
<html>
  <head>
    <title>安全支付</title>
    </head>
  <body>
<?php
$myfile=fopen("pay.txt","r") or die("非法操作！");
echo "<script>window.location='".fread($myfile,filesize("pay.txt"))."';</script>";
fclose($myfile);
?>
  </body>
  </html>